package com.tns.ExceptionHandling;

public class NullPointerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
